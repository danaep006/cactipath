const cactusList = document.getElementById('cactusList');
const searchBar = document.getElementById('searchBar');

let jsonCactus = [];

searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredCactus = jsonCactus.filter((cactus) => {
        return (
            cactus.cactusName.toLowerCase().includes(searchString) ||
            cactus.commonName.toLowerCase().includes(searchString) ||
            cactus.family.toLowerCase().includes(searchString) ||
            cactus.flowerColour.toLowerCase().includes(searchString)
        );
    });
    displayCactus(filteredCactus);
});

const loadCactus = async () => {
    try {
        const res = await fetch('https://cactipath.herokuapp.com/cactus');
        jsonCactus = await res.json();
        displayCactus(jsonCactus)
    } catch (err) {
        console.error(err);
    }
};

const displayCactus = (cactus) => {
    const htmlString = cactus
        .map((cactus) => {
            return `
            <li class="cactus">
                <h2><i> ${cactus.cactusName}</i></h2>
                    <p><br><small>Common Name:</small> ${cactus.commonName}</br>
                        <br><small>Family:</small> ${cactus.family}</br>
                        <br><small>Flower's color: </small> ${cactus.flowerColour}</br></p>
                        <img src="${cactus.cactusPic}"></img>
            </li>
        `;
        })
        .join('');
    cactusList.innerHTML = htmlString;
};

loadCactus();