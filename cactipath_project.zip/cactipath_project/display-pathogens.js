const pathogenList = document.getElementById('pathogenList');
const searchBar = document.getElementById('searchBar');

let jsonPathogen = [];

searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredPathogen = jsonPathogen.filter((pathogen) => {
        return (
            pathogen.pathogenName.toLowerCase().includes(searchString) ||
            pathogen.type.toLowerCase().includes(searchString) ||
            pathogen.disease.toLowerCase().includes(searchString) ||
            pathogen.symptoms.toLowerCase().includes(searchString)
        );
    });
    displayPathogen(filteredPathogen);
});

const loadPathogen = async () => {
    try {
        const res = await fetch('https://cactipath.herokuapp.com/pathogen');
        jsonPathogen = await res.json();
        displayPathogen(jsonPathogen)
    } catch (err) {
        console.error(err)
    }
};

const displayPathogen = (pathogen) => {
    const htmlString = pathogen
        .map((pathogen) => {
            return `
            <li class="pathogen">
                <h2><i>${pathogen.pathogenName}</i></h2>
                    <p><br><small>Disease:</small> ${pathogen.disease}</br>
                        <br><small>Type:</small> ${pathogen.type}</br>
                        <br><small>Symptoms:</small> ${pathogen.symptoms}</br>
                        <br><small>Cure:</small> ${pathogen.cure}</br></p>
                        <img src="${pathogen.pathogenPic}"></img>
            </li>
        `;
        })
        .join('');
    pathogenList.innerHTML = htmlString;
};

loadPathogen();