const { request } = require('express')
const express = require('express')
const mysql = require('mysql')


const router = express.Router()

//Checks router's working.
router.get('/message_data', (req, res) => {
    console.log("it's a me router!")
    res.end()
  })

//Fetch all cacti
router.get("/cactus", (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM cacti"
    connection.query(queryString, (err, rows, fields) => {
      if (err) {
        console.log("Failed to query for cacti: " + err)
        res.sendStatus(500)
        return
      }
    
      res.json(rows)
    })
})

//Fetch all pathogens
router.get("/pathogen", (req, res) => {
  const connection = getConnection()
const queryString = "SELECT * FROM pathogens"
connection.query(queryString, (err, rows, fields) => {
  if (err) {
    console.log("Failed to query for pathogens: " + err)
    res.sendStatus(500)
    return
  }
  res.json(rows)
  })
})


//Fetch all cactipath
router.get("/cactipath", (req, res) => {
  const connection = getConnection()
  const queryString = "SELECT * FROM cactipath"
  connection.query(queryString, (err, rows, fields) => {
    if (err) {
      console.log("Failed to query for cactipath: " + err)
      res.sendStatus(500)
      return
    }
  
    res.json(rows)
  })
})

const pool= mysql.createPool ({
    connectionLimit: 10,
    host: 'us-cdbr-east-02.cleardb.com',
    user: 'bae5ef4cebb96e',
    database: 'heroku_26736b1fff2a7a9',
    password: 'f169c41b',
})

function getConnection() {
    return pool
}

//Fetch cactus by id
router.get('/cactus/:id', (req, res) => {
  console.log("Fetching cactus with id: " + req.params.id)
  
  const connection = getConnection()

  const cactusId = req.params.id
  const queryString = "SELECT * FROM cacti WHERE id = ?"

  connection.query(queryString, [cactusId], (err, rows, fields) => {
      if (err) {
      console.log("Fail to query: " + err)
      res.sendStatus(500)
      return
      //throw err
      }
  
      console.log("LALALALALALA")
  
      const cactus = rows.map((row) => {
          return {cactusName: row.cactusName, commonName: row.commonName, family: row.family, flowerColour: row.flowerColour, cactusPic: row.cactusPic}
  })
  res.json(cactus)
  })
})

//Fetch pathogen by id
router.get('/pathogen/:id', (req, res) => {

  console.log("Fetching pathogen with id: " + req.params.id)
  
  const connection = getConnection()

  const pathogenId = req.params.id
  const queryString = "SELECT * FROM pathogens WHERE id = ?"

  connection.query(queryString, [pathogenId], (err, rows, fields) => {
  if (err) {
      console.log("Fail to query: " + err)
      res.sendStatus(500)
      return
      //throw err
  }
  
  console.log("tataaaaa")

  const pathogen = rows.map(() => {
      return {pathogenName: row.pathogenName, disease: row.disease, type: row.type, symptoms: row.symptoms, cure: row.cure, pathogenPic: row.pathogenPic}
  })

  res.json(pathogen)
  }) 
})

//Fetch cactipath by id
router.get('/cactipath/:id', (req, res) => {
  console.log("Fetching cactus with id: " + req.params.id)
  
  const connection = getConnection()

  const cactipathId = req.params.id
  const queryString = "SELECT * FROM cactipath WHERE id = ?"

  connection.query(queryString, [cactipathId], (err, rows, fields) => {
      if (err) {
      console.log("Fail to query: " + err)
      res.sendStatus(500)
      return
      //throw err
      }
  
      console.log("LALALALALALA")
  
      const cactus = rows.map((row) => {
          return {cacti_id: row.cacti_id, path_id: row.path_id}
  })
  res.json(cactipath)
  })
})

//Add a cactus
router.post('/cactus_add', (req, res) => {
    console.log("Trying to add a new cactus...")
    
    console.log("Cactus name: " + req.body.create_cactusName)
    const cactusName = req.body.create_cactusName
    const commonName = req.body.create_commonName
    const family = req.body.create_family
    const flowerColour = req.body.create_flowerColour
    const cactusPic = req.body.create_cactusPic
    
    const queryString = "INSERT INTO cacti (cactusName, commonName, family, flowerColour, cactusPic) VALUES (?, ?, ?, ?, ?)"
    getConnection().query(queryString, [cactusName, commonName, family, flowerColour, cactusPic], (err, results, fields) => {
        if(err) {
            console.log("Failed to insert new cactus!" + err)
            res.sendStatus(500)
            return
        }    
    res.send("Success! You inserted a new Cactus with id: " + results.insertId);
  })
})

//Add a pathogen
router.post('/pathogen_add', (req, res) => {
 
  console.log("Trying to add a new pathogen...")
  
  const pathogenName = req.body.create_pathogenName
  const disease = req.body.create_disease
  const type = req.body.create_type
  const symptoms = req.body.create_symptoms
  const cure = req.body.create_cure
  const pathogenPic = req.body.create_pathogenPic
  
  const queryString = "INSERT INTO pathogens (pathogenName, disease, type, symptoms, cure, pathogenPic) VALUES (?, ?, ?, ?, ?, ?)"
  getConnection().query(queryString, [pathogenName, disease, type, symptoms, cure, pathogenPic], (err, results, fields) => {
      if( err) {
          console.log("Failed to insert pathogen!" + err)
          res.sendStatus(500)
          return
      }
      res.send("Success! You inserted a new pathogen with id: " + results.insertId);
  res.end()
})
})

//Add a cactipath
router.post('/cactipath_add', (req, res) => {
  console.log("Trying to add a new cactipath...")
  
  const cacti_id = req.body.create_cacti_id
  const path_id = req.body.create_path_id
  
  const queryString = "INSERT INTO cactipath (acti_id, path_id) VALUES (?, ?)"
  getConnection().query(queryString, [cacti_id, path_id], (err, results, fields) => {
      if(err) {
          console.log("Failed to insert new cactipath!" + err)
          res.sendStatus(500)
          return
      }    
  res.send("Success! You inserted a new Cactipath with id: " + results.insertId);
  })
})

//Delete a cactus
router.post('/cactus_delete', async (req, res) => {
  const connection = getConnection()

  const cactusId = req.body.id
  const queryString = "DELETE FROM cacti WHERE id = ? "
  
  connection.query(queryString, [cactusId], (err, rows, fields) => {
    if (err) {
      console.log("Fail to delete cactus: " + err)
      res.sendStatus(500)
      return
    }
    res.redirect('Cactus deleted successfully.')
  })
});

//Delete a pathogen
router.post('/pathogen_delete', async (req, res) => {
  const connection = getConnection()

  const pathogenId = req.body.id
  const queryString = "DELETE FROM pathogen WHERE id = ? "
  
  connection.query(queryString, [pathogenId], (err, rows, fields) => {
    if (err) {
      console.log("Fail to delete pathogen: " + err)
      res.sendStatus(500)
      return
    }
    res.send('Pathogen deleted successfully.')
  })
});

//Delete a cactus
router.post('/cactipath_delete', async (req, res) => {
  const connection = getConnection()

  const cactipathId = req.body.id
  const queryString = "DELETE FROM cactipath WHERE id = ? "
  
  connection.query(queryString, [cactipathId], (err, rows, fields) => {
    if (err) {
      console.log("Fail to delete cactipath: " + err)
      res.sendStatus(500)
      return
    }
    res.redirect('Cactipath deleted successfully.')
  })
});

//Update a cactus
router.post('/cactus_update', async (req, res) => {
  const connection = getConnection()

  console.log("Trying to update a cactus...")
  
  const cactusName = req.body.update_cactusName
  const commonName = req.body.update_commonName
  const family = req.body.update_family
  const flowerColour = req.body.update_flowerColour
  const cactusPic = req.body.update_cactusPic
  const cactusId = req.body.id

  const queryString = "UPDATE cacti SET cactusName = ?, commonName = ?, family = ?, flowerColour = ?, cactusPic = ? WHERE id = ?"
  connection.query(queryString, [cactusName, commonName, family, flowerColour, cactusPic, cactusId], (err, results, fields) => {
    if (err) {
      console.log(err)
      res.sendStatus(500)
      return
    }
    res.send("Success! You updated the cactus with id: " + req.body.id)
  })
})


module.exports = router