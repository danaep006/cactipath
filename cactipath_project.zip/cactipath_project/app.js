const express = require('express')
const {ADDRGETNETWORKPARAMS } = require('dns')
const app = express()
const morgan = require('morgan')
const mysql = require('mysql')
const QueryString = require('qs')
const fs = require('fs')

const cors = require ('cors')

const bcrypt = require('bcryptjs')
const bodyParser = require('body-parser')

const { get } = require('http')

app.use(bodyParser.urlencoded({extended: false}))

app.use(express.static('./routes'))
app.use(express.static('./administrators'))

app.use(express.static('./'))

app.use(cors())

app.use(morgan('short')) 

const router = require('./routes/data.js')
app.use(router)

const administrators = require('./administrators/admin.js')
app.use(administrators)

app.get("/", (req, res) => {  
  fs.readFile('./index.html')
})

const PORT = process.env.PORT || 3003
app.listen(PORT, () => {
  console.log("Server is up!" + PORT)
})