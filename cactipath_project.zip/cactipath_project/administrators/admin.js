const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const bcrypt = require('bcryptjs');
const mysql = require('mysql');
const { route } = require('../routes/data');
const { runInNewContext } = require('vm');

const administrators = express.Router()

administrators.use(bodyParser.urlencoded({extended: false}));
administrators.use(bodyParser.json());

administrators.get('/message_login', (req, res) => {
    console.log("it's a me router!")
    res.end()
  })

//feching admins
  administrators.get("/admin", (req, res) => {
    const connection = getConnection()
    const queryString = "SELECT * FROM admin"
    connection.query(queryString, (err, rows, fields) => {
      if (err) {
        console.log("Failed to query for admins: " + err)
        res.sendStatus(500)
        return
      }
      res.json(rows)
    })
})

const pool= mysql.createPool ({
    connectionLimit: 10,
    host: 'us-cdbr-east-02.cleardb.com',
    user: 'bae5ef4cebb96e',
    database: 'heroku_26736b1fff2a7a9',
    password: 'f169c41b',
})

function getConnection() {
    return pool
}

//fetching admins by id
administrators.get('/admin/:id', (req, res) => {
    console.log("Fetching admin with id: " + req.params.id)
    
    const connection = getConnection()

    const username = req.params.id
    const queryString = "SELECT * FROM admin WHERE id = ?"

    connection.query(queryString, [username], (err, rows, fields) => {
        if (err) {
        console.log("Fail to query: " + err)
        res.sendStatus(500)
        return
        //throw err
        }

        console.log("LALALALALALA")

        const admin = rows.map((row) => {
            return {username: row.username, hashedPassword: row.hashedPassword}
    })
    res.json(admin)
  })
})


//admin check - basic
administrators.post('/auth', async (req, res) => {
  const connection = getConnection()

  const password = req.body.password
  const username = req.body.username
  
 if ((username === "danae" && password === "alohomora") || username === "thodoris" && password === "password") {
   res.redirect('../administrator.html')
  }
  else {
    res.redirect('../login.html');
    }			
    res.end();
})

administrators.use(function(err, req, res, next) {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

module.exports = administrators;