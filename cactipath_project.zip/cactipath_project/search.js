const cactusList = document.getElementById('cactusList');
const pathogenList = document.getElementById('pathogenList');
const cactipathList = document.getElementById('cactipathList');

const advancedSearchBar = document.getElementById('advancedSearchBar');

let jsonCactus = [];

advancedSearchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredCactus = jsonCactus.filter((cactus) => {
        return (
            cactus.cactusName.toLowerCase().includes(searchString) ||
            cactus.commonName.toLowerCase().includes(searchString)
        );
    });
    displayCactus(filteredCactus);
});

const loadCactus = async () => {
    try {
        const res = await fetch('https://cactipath.herokuapp.com/cactus');
        jsonCactus = await res.json();
        displayCactus(jsonCactus)
    } catch (err) {
        console.error(err);
    }
};

const displayCactus = (cactus) => {
    const htmlString = cactus
        .map((cactus) => {
            return `
            <li class="cactus">
                <h2><i> ${cactus.cactusName}</i></h2>
                    <p><br><small>Common Name:</small> ${cactus.commonName}</br>
                        <br><small>Family:</small> ${cactus.family}</br>
                        <br><small>Flower's color: </small> ${cactus.flowerColour}</br></p>
                        <img src="${cactus.cactusPic}"></img>
            </li>
        `;
        })
        .join('');
    cactusList.innerHTML = htmlString;
};

loadCactus();


// const pool= mysql.createPool ({
//     connectionLimit: 10,
//     host: 'us-cdbr-east-02.cleardb.com',
//     user: 'bae5ef4cebb96e',
//     database: 'heroku_26736b1fff2a7a9',
//     password: 'f169c41b',
// })

// function getConnection() {
//     return pool
// }

// search.post('/cactipath_cacti', async (req, res) => {
//     const connection = getConnection()
  
//     console.log("Trying to fetch cactus & pathogens")
    
//     const cactusName = req.body.cactusName

//     queryString= "SELECT cactipath.path_id FROM cactipath INNER JOIN pathogens ON pathogens.id = cactipath.path_id INNER JOIN cacti ON cactipath.cacti_id = cacti.id WHERE cactipath.cacti_id = (SELECT id FROM cacti WHERE cactusName= ?)"

//     connection.query(queryString, [cactusName], (err, results, fields) => {
//       if (err) {
//         console.log(err)
//         res.send("Failed to fetch cactus & pathogen!")
//         return
//       }
//       res.send("Success!")
//     })
//   })

//   SELECT cactipath.path_id
//   FROM cactipath
//   INNER JOIN pathogens
//   ON pathogens.id = cactipath.path_id
//   INNER JOIN cacti
//   ON cactipath.cacti_id = cacti.id
//   WHERE cactipath.cacti_id = (SELECT id FROM cacti WHERE cactusName= ?);